https://github.com/cpldcpu/light_ws2812


This is a small Ansi-C library to control WS2811/WS2812 based RGB Leds and strings. 
Only the 800kHz high-speed mode is supported. 
This library uses a bit-banging approach with cycle optimized assembler innerloops. 

Please find updates on https://github.com/cpldcpu/light_ws2812
